import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { requireFeature } from "../middleware/features.js";

const router = Router();

// ADMIN: create assignment
router.post(
  "/",
  requireAuth,
  requireRole("ADMIN"),
  requireFeature("enableSubjectAssignments"),
  async (req, res) => {
    try {
      const { teacherId, classId, subjectId } = req.body;

      if (!teacherId || !classId || !subjectId) {
        return res.status(400).json({ message: "teacherId, classId, subjectId are required" });
      }

      // Ensure all exist
      const [t, c, s] = await Promise.all([
        prisma.teacher.findUnique({ where: { id: teacherId }, include: { user: true } }),
        prisma.class.findUnique({ where: { id: classId } }),
        prisma.subject.findUnique({ where: { id: subjectId } }),
      ]);

      if (!t) return res.status(404).json({ message: "Teacher not found" });
      if (!t.user?.isActive) return res.status(400).json({ message: "Teacher user is deactivated" });
      if (!c) return res.status(404).json({ message: "Class not found" });
      if (!s) return res.status(404).json({ message: "Subject not found" });

      const created = await prisma.teachingAssignment.create({
        data: { teacherId, classId, subjectId },
        include: { teacher: true, class: true, subject: true },
      });

      return res.status(201).json(created);
    } catch (err) {
      if (err?.code === "P2002") {
        return res.status(409).json({ message: "Assignment already exists" });
      }
      console.error("CREATE ASSIGNMENT ERROR:", err);
      return res.status(500).json({ message: "Server error" });
    }
  }
);

// ADMIN + TEACHER: list assignments (filters supported)
router.get(
  "/",
  requireAuth,
  requireRole("ADMIN", "TEACHER"),
  requireFeature("enableSubjectAssignments"),
  async (req, res) => {
    try {
      const { teacherId, classId, subjectId } = req.query;

      const assignments = await prisma.teachingAssignment.findMany({
        where: {
          isActive: true,
          ...(teacherId ? { teacherId: String(teacherId) } : {}),
          ...(classId ? { classId: String(classId) } : {}),
          ...(subjectId ? { subjectId: String(subjectId) } : {}),
        },
        include: {
          teacher: { include: { user: { select: { email: true, isActive: true } } } },
          class: true,
          subject: true,
        },
        orderBy: { createdAt: "desc" },
      });

      return res.json(assignments);
    } catch (err) {
      console.error("LIST ASSIGNMENTS ERROR:", err);
      return res.status(500).json({ message: "Server error" });
    }
  }
);

export default router;
