// src/routes/auth.js
import { Router } from "express";
import bcrypt from "bcrypt";
import { prisma } from "../lib/prisma.js";
import { signToken } from "../utils/jwt.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = Router();

const cleanEmail = (email) => String(email || "").trim().toLowerCase();

const validatePassword = (password) => {
  const p = String(password || "");
  // MVP rules (simple, not perfect):
  // - at least 8 chars
  // - at least 1 letter and 1 number
  const okLen = p.length >= 8;
  const hasLetter = /[A-Za-z]/.test(p);
  const hasNumber = /\d/.test(p);
  return okLen && hasLetter && hasNumber;
};

/**
 * AUTH
 * Base path: /api/auth
 */

// Signup (MVP): creates a user.
// Security improvement: role assignment is controlled.
// - If no token: only ADMIN role allowed (first setup)
// - If token + ADMIN: can create TEACHER/STUDENT accounts
router.post("/signup", async (req, res) => {
  try {
    const email = cleanEmail(req.body?.email);
    const password = String(req.body?.password || "");
    const requestedRole = req.body?.role;

    if (!email || !password) {
      return res.status(400).json({ message: "email and password are required" });
    }

    if (!validatePassword(password)) {
      return res.status(400).json({
        message: "Password must be at least 8 chars and include letters + numbers",
      });
    }

    // If role is provided, only allow ADMIN to set it (otherwise default ADMIN for first setup)
    let role = "ADMIN";
    if (requestedRole) {
      role = String(requestedRole).toUpperCase();
      // Only allow known roles
      if (!["ADMIN", "TEACHER", "STUDENT"].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }
    }

    // Optional: if you want to restrict role creation:
    // If a client wants TEACHER/STUDENT, require ADMIN auth
    if (requestedRole && role !== "ADMIN") {
      // Try to verify bearer token if present
      // If not present or not admin -> block
      const header = req.headers.authorization || "";
      const [type, token] = header.split(" ");
      if (type !== "Bearer" || !token) {
        return res.status(403).json({ message: "Only ADMIN can create non-admin users" });
      }
      // Reuse your middleware logic by manually verifying:
      // (Simpler approach: create a separate /admin/create-user route later)
      // For now, we’ll just deny unless you implement a proper admin create route.
      return res.status(403).json({ message: "Use an admin-only endpoint to create TEACHER/STUDENT" });
    }

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) return res.status(409).json({ message: "Email already exists" });

    const hashed = await bcrypt.hash(password, 10);

    const user = await prisma.user.create({
      data: {
        email,
        password: hashed,
        role,
      },
      select: { id: true, email: true, role: true, isActive: true, schoolId: true, createdAt: true },
    });

    const token = signToken({ sub: user.id, role: user.role, schoolId: user.schoolId ?? null });

    return res.status(201).json({ user, token });
  } catch (err) {
    console.error("SIGNUP ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// Login
router.post("/login", async (req, res) => {
  try {
    const email = cleanEmail(req.body?.email);
    const password = String(req.body?.password || "");

    if (!email || !password) {
      return res.status(400).json({ message: "email and password are required" });
    }

    const user = await prisma.user.findUnique({ where: { email } });

    // Don’t leak which part failed
    if (!user || !user.isActive) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(401).json({ message: "Invalid credentials" });

    const token = signToken({ sub: user.id, role: user.role, schoolId: user.schoolId ?? null });

    return res.json({
      user: { id: user.id, email: user.email, role: user.role, schoolId: user.schoolId },
      token,
    });
  } catch (err) {
    console.error("LOGIN ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// (Optional) ADMIN-only endpoint to create users with roles safely
router.post("/admin/create-user", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    const email = cleanEmail(req.body?.email);
    const password = String(req.body?.password || "");
    const role = String(req.body?.role || "").toUpperCase();

    if (!email || !password || !role) {
      return res.status(400).json({ message: "email, password, role are required" });
    }

    if (!["ADMIN", "TEACHER", "STUDENT"].includes(role)) {
      return res.status(400).json({ message: "Invalid role" });
    }

    if (!validatePassword(password)) {
      return res.status(400).json({
        message: "Password must be at least 8 chars and include letters + numbers",
      });
    }

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) return res.status(409).json({ message: "Email already exists" });

    const hashed = await bcrypt.hash(password, 10);

    const user = await prisma.user.create({
      data: { email, password: hashed, role },
      select: { id: true, email: true, role: true, isActive: true, schoolId: true, createdAt: true },
    });

    return res.status(201).json(user);
  } catch (err) {
    console.error("ADMIN CREATE USER ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// Assign / change a user's school (ADMIN only)
// PATCH /api/auth/users/:id/school
// Body: { schoolId: "school_demo_001", schoolName?: "Demo Primary" }
router.patch("/users/:id/school", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    const { id } = req.params;
    const { schoolId, schoolName } = req.body;

    if (!schoolId) return res.status(400).json({ message: "schoolId is required" });

    // Ensure school exists
    await prisma.school.upsert({
      where: { id: String(schoolId) },
      update: schoolName ? { name: String(schoolName).trim() } : {},
      create: {
        id: String(schoolId),
        name: schoolName ? String(schoolName).trim() : "Unnamed School",
      },
    });

    const updated = await prisma.user.update({
      where: { id: String(id) },
      data: { schoolId: String(schoolId) },
      select: { id: true, email: true, role: true, isActive: true, schoolId: true },
    });

    return res.json(updated);
  } catch (err) {
    console.error("SET USER SCHOOL ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// Current user (who am I)
router.get("/me", requireAuth, async (req, res) => {
  try {
    // requireAuth should set req.user (common pattern). If not, adjust.
    // We'll safely fetch from DB using req.user.sub or req.userId (depending on your middleware).
    const userId = req.user?.sub || req.userId || req.user?.id;

    if (!userId) return res.status(401).json({ message: "Unauthorized" });

    const user = await prisma.user.findUnique({
      where: { id: String(userId) },
      select: { id: true, email: true, role: true, isActive: true, schoolId: true },
    });

    if (!user || !user.isActive) return res.status(401).json({ message: "Unauthorized" });

    return res.json({ user });
  } catch (err) {
    console.error("ME ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});


export default router;
