import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { requireFeature } from "../middleware/features.js";

const router = Router();

// ADMIN: assign a class teacher (1 class -> 1 teacher)
router.post(
  "/",
  requireAuth,
  requireRole("ADMIN"),
  requireFeature("enableClassTeachers"),
  async (req, res) => {
    try {
      const { classId, teacherId } = req.body;
      if (!classId || !teacherId) {
        return res.status(400).json({ message: "classId and teacherId are required" });
      }

      const [c, t] = await Promise.all([
        prisma.class.findUnique({ where: { id: classId } }),
        prisma.teacher.findUnique({ where: { id: teacherId }, include: { user: true } }),
      ]);

      if (!c) return res.status(404).json({ message: "Class not found" });
      if (!t) return res.status(404).json({ message: "Teacher not found" });
      if (!t.user?.isActive) return res.status(400).json({ message: "Teacher user is deactivated" });

      const created = await prisma.classTeacher.upsert({
        where: { classId },
        update: { teacherId, isActive: true },
        create: { classId, teacherId },
        include: { class: true, teacher: true },
      });

      return res.status(201).json(created);
    } catch (err) {
      console.error("ASSIGN CLASS TEACHER ERROR:", err);
      return res.status(500).json({ message: "Server error" });
    }
  }
);

// ADMIN + TEACHER: list class teachers
router.get(
  "/",
  requireAuth,
  requireRole("ADMIN", "TEACHER"),
  requireFeature("enableClassTeachers"),
  async (req, res) => {
    try {
      const rows = await prisma.classTeacher.findMany({
        where: { isActive: true },
        include: {
          class: true,
          teacher: { include: { user: { select: { email: true, isActive: true } } } },
        },
        orderBy: { createdAt: "desc" },
      });
      return res.json(rows);
    } catch (err) {
      console.error("LIST CLASS TEACHERS ERROR:", err);
      return res.status(500).json({ message: "Server error" });
    }
  }
);

export default router;
