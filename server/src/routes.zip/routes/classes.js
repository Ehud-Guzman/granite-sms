import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = Router();

const cleanStr = (v) => (typeof v === "string" ? v.trim() : "");
const toInt = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.trunc(n) : NaN;
};

/**
 * CLASSES
 * Base path: /api/classes
 */

// ADMIN: create class
router.post("/", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    const name = cleanStr(req.body?.name);
    const streamRaw = req.body?.stream;
    const stream = streamRaw ? cleanStr(streamRaw) : null;
    const year = toInt(req.body?.year);

    if (!name || Number.isNaN(year)) {
      return res.status(400).json({ message: "name (string) and year (number) are required" });
    }

    const created = await prisma.class.create({
      data: {
        name,
        stream: stream || null,
        year,
      },
    });

    return res.status(201).json(created);
  } catch (err) {
    if (err?.code === "P2002") {
      return res.status(409).json({ message: "Class already exists for that name/stream/year" });
    }
    console.error("CREATE CLASS ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// ADMIN + TEACHER: list classes
// Optional query params:
// - year=2026
router.get("/", requireAuth, requireRole("ADMIN", "TEACHER"), async (req, res) => {
  try {
    const yearParam = req.query.year;
    const year = yearParam !== undefined ? toInt(yearParam) : null;

    const where = {};
    if (yearParam !== undefined) {
      if (Number.isNaN(year)) {
        return res.status(400).json({ message: "year must be a number" });
      }
      where.year = year;
    }

    const classes = await prisma.class.findMany({
      where,
      orderBy: [{ year: "desc" }, { name: "asc" }, { stream: "asc" }],
    });

    return res.json(classes);
  } catch (err) {
    console.error("LIST CLASSES ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

export default router;
