// src/routes/fees.js
import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { loadSubscription, requireEntitlement } from "../middleware/subscription.js";
import PDFDocument from "pdfkit";

const ALLOWED_PAYMENT_METHODS = ["CASH", "MPESA", "BANK", "CHEQUE", "OTHER"];

function normalizePaymentMethod(method) {
  const m = String(method || "CASH").trim().toUpperCase();
  if (!ALLOWED_PAYMENT_METHODS.includes(m)) return null;
  return m;
}

function computeInvoiceStatus(total, paid) {
  const balance = Math.max(Number(total) - Number(paid), 0);
  const status = balance === 0 ? "PAID" : paid > 0 ? "PARTIALLY_PAID" : "ISSUED";
  return { balance, status };
}

function makeReceiptNo() {
  const d = new Date();
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  const rand = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `RCPT-${y}${m}${day}-${rand}`;
}

const router = Router();

router.use(requireAuth);
router.use(loadSubscription);

/**
 * --------------------------------------
 * Subscription (demo/admin setup endpoints)
 * --------------------------------------
 */

router.get("/subscription", async (req, res) => {
  res.json({
    schoolId: req.schoolId,
    subscription: req.subscription,
    mode: req.subscription ? "SUBSCRIBED" : "READ_ONLY",
  });
});

router.post("/subscription", requireRole("ADMIN"), async (req, res) => {
  const {
    schoolName,
    schoolCode,
    status = "ACTIVE",
    entitlements = { FEES_WRITE: true },
    currentPeriodEnd,
  } = req.body;

  if (!schoolName || String(schoolName).trim().length < 2) {
    return res.status(400).json({ message: "schoolName is required (min 2 chars)." });
  }

  const school = await prisma.school.upsert({
    where: { id: req.schoolId },
    update: {
      name: String(schoolName).trim(),
      code: schoolCode ? String(schoolCode).trim() : undefined,
    },
    create: {
      id: req.schoolId,
      name: String(schoolName).trim(),
      code: schoolCode ? String(schoolCode).trim() : null,
    },
  });

  const sub = await prisma.subscription.create({
    data: {
      schoolId: school.id,
      status,
      entitlements,
      currentPeriodEnd: currentPeriodEnd ? new Date(currentPeriodEnd) : null,
    },
  });

  res.status(201).json({ school, subscription: sub });
});

/**
 * --------------------
 * Fee Items
 * --------------------
 */

router.get("/items", async (req, res) => {
  const items = await prisma.feeItem.findMany({
    where: { schoolId: req.schoolId },
    orderBy: { createdAt: "desc" },
  });
  res.json(items);
});

router.post("/items", requireRole("ADMIN"), requireEntitlement("FEES_WRITE"), async (req, res) => {
  const { name, code } = req.body;

  if (!name || String(name).trim().length < 2) {
    return res.status(400).json({ message: "name is required (min 2 chars)" });
  }

  try {
    const item = await prisma.feeItem.create({
      data: {
        schoolId: req.schoolId,
        name: String(name).trim(),
        code: code ? String(code).trim() : null,
      },
    });
    res.status(201).json(item);
  } catch {
    res.status(409).json({ message: "Fee item already exists." });
  }
});

router.patch("/items/:id", requireRole("ADMIN"), requireEntitlement("FEES_WRITE"), async (req, res) => {
  const { id } = req.params;
  const { name, code, isActive } = req.body;

  const existing = await prisma.feeItem.findFirst({ where: { id, schoolId: req.schoolId } });
  if (!existing) return res.status(404).json({ message: "Fee item not found." });

  try {
    const updated = await prisma.feeItem.update({
      where: { id },
      data: {
        name: name !== undefined ? String(name).trim() : undefined,
        code: code !== undefined ? (code ? String(code).trim() : null) : undefined,
        isActive: isActive !== undefined ? Boolean(isActive) : undefined,
      },
    });
    res.json(updated);
  } catch {
    res.status(409).json({ message: "Update conflict (maybe duplicate name)." });
  }
});

router.delete("/items/:id", requireRole("ADMIN"), requireEntitlement("FEES_WRITE"), async (req, res) => {
  const { id } = req.params;

  const existing = await prisma.feeItem.findFirst({ where: { id, schoolId: req.schoolId } });
  if (!existing) return res.status(404).json({ message: "Fee item not found." });

  await prisma.feeItem.update({ where: { id }, data: { isActive: false } });
  res.json({ message: "Fee item deactivated." });
});

/**
 * --------------------
 * Fee Plans
 * --------------------
 */

router.get("/plans", async (req, res) => {
  const { classId, year, term } = req.query;

  const plans = await prisma.feePlan.findMany({
    where: {
      schoolId: req.schoolId,
      classId: classId ? String(classId) : undefined,
      year: year ? Number(year) : undefined,
      term: term ? String(term) : undefined,
    },
    include: { items: { include: { feeItem: true } } },
    orderBy: { createdAt: "desc" },
  });

  res.json(plans);
});

router.post("/plans", requireRole("ADMIN"), requireEntitlement("FEES_WRITE"), async (req, res) => {
  const { classId, year, term, title, items } = req.body;

  if (!classId || !year || !term) {
    return res.status(400).json({ message: "classId, year, term are required." });
  }
  if (!Array.isArray(items) || items.length < 1) {
    return res.status(400).json({ message: "items[] is required (min 1)." });
  }

  try {
    const plan = await prisma.feePlan.create({
      data: {
        schoolId: req.schoolId,
        classId: String(classId),
        year: Number(year),
        term: String(term),
        title: title ? String(title) : null,
        items: {
          create: items.map((it) => ({
            feeItemId: String(it.feeItemId),
            amount: Number(it.amount),
            required: it.required !== undefined ? Boolean(it.required) : true,
          })),
        },
      },
      include: { items: true },
    });

    res.status(201).json(plan);
  } catch {
    res.status(409).json({ message: "Plan already exists for class/year/term OR bad feeItemId." });
  }
});

/**
 * --------------------
 * Invoices
 * --------------------
 */

router.get("/invoices", async (req, res) => {
  const { studentId, classId, year, term, status } = req.query;

  const invoices = await prisma.feeInvoice.findMany({
    where: {
      schoolId: req.schoolId,
      studentId: studentId ? String(studentId) : undefined,
      classId: classId ? String(classId) : undefined,
      year: year ? Number(year) : undefined,
      term: term ? String(term) : undefined,
      status: status ? String(status) : undefined,
    },
    include: { lines: true },
    orderBy: { createdAt: "desc" },
  });

  res.json(invoices);
});

router.get("/invoices/:id", async (req, res) => {
  const { id } = req.params;

  const invoice = await prisma.feeInvoice.findFirst({
    where: { id, schoolId: req.schoolId },
    include: { lines: { include: { feeItem: true } }, payments: true },
  });

  if (!invoice) return res.status(404).json({ message: "Invoice not found." });
  res.json(invoice);
});

router.post("/invoices/generate", requireRole("ADMIN"), requireEntitlement("FEES_WRITE"), async (req, res) => {
  const { studentId, classId, year, term, feePlanId } = req.body;

  if (!studentId || !classId || !year || !term || !feePlanId) {
    return res.status(400).json({ message: "studentId, classId, year, term, feePlanId are required." });
  }

  const plan = await prisma.feePlan.findFirst({
    where: { id: String(feePlanId), schoolId: req.schoolId },
    include: { items: true },
  });
  if (!plan) return res.status(404).json({ message: "Fee plan not found." });

  const total = plan.items.reduce((sum, it) => sum + (it.amount || 0), 0);

  try {
    const invoice = await prisma.feeInvoice.create({
      data: {
        schoolId: req.schoolId,
        studentId: String(studentId),
        classId: String(classId),
        year: Number(year),
        term: String(term),
        status: "ISSUED",
        total,
        paid: 0,
        balance: total,
        lines: {
          create: plan.items.map((it) => ({
            feeItemId: it.feeItemId,
            amount: it.amount,
          })),
        },
      },
      include: { lines: true },
    });

    res.status(201).json(invoice);
  } catch {
    res.status(409).json({ message: "Invoice already exists for that student/year/term." });
  }
});

router.post("/invoices/:id/void", requireRole("ADMIN"), requireEntitlement("FEES_WRITE"), async (req, res) => {
  try {
    const { id } = req.params;
    const reason = String(req.body?.reason || "").trim();

    if (!reason) return res.status(400).json({ message: "Void reason is required." });

    const result = await prisma.$transaction(async (tx) => {
      const invoice = await tx.feeInvoice.findFirst({
        where: { id: String(id), schoolId: req.schoolId },
        include: { payments: true },
      });

      if (!invoice) {
        const e = new Error("Invoice not found.");
        e.status = 404;
        throw e;
      }

      const activePayments = (invoice.payments || []).filter((p) => !p.isReversed);
      if (activePayments.length > 0) {
        const e = new Error("Cannot void invoice with active payments. Reverse payments first.");
        e.status = 400;
        throw e;
      }

      const updated = await tx.feeInvoice.update({
        where: { id: invoice.id },
        data: {
          status: "VOID",
          voidedAt: new Date(),
          voidedBy: req.user?.sub || req.user?.id || null,
          voidReason: reason,
          balance: 0,
        },
      });

      return updated;
    });

    return res.json({ message: "Invoice voided successfully.", invoice: result });
  } catch (err) {
    console.error("VOID INVOICE ERROR:", err);
    return res.status(err?.status || 500).json({ message: err?.message || "Server error" });
  }
});

/**
 * --------------------
 * Student summary / statement
 * --------------------
 */

// GET /api/fees/students/:studentId/summary?year=2026&term=TERM1
router.get("/students/:studentId/summary", async (req, res) => {
  const { studentId } = req.params;
  const { year, term } = req.query;

  // If STUDENT: only own record, and scoped to school
  if (req.user?.role === "STUDENT") {
    const me = await prisma.student.findFirst({
      where: { userId: req.user.sub || req.user.id, schoolId: req.schoolId },
      select: { id: true },
    });
    if (!me || me.id !== String(studentId)) {
      return res.status(403).json({ message: "Students can only view their own fee summary." });
    }
  }

  // ✅ Ensure student exists in this school (multitenancy safe)
  const student = await prisma.student.findFirst({
    where: { id: String(studentId), schoolId: req.schoolId },
    select: { id: true },
  });
  if (!student) return res.status(404).json({ message: "Student not found." });

  const invoices = await prisma.feeInvoice.findMany({
    where: {
      schoolId: req.schoolId,
      studentId: String(studentId),
      year: year ? Number(year) : undefined,
      term: term ? String(term) : undefined,
      status: { not: "VOID" },
    },
    orderBy: { createdAt: "desc" },
  });

  const summary = invoices.reduce(
    (acc, inv) => {
      acc.total += inv.total;
      acc.paid += inv.paid;
      acc.balance += inv.balance;
      acc.count += 1;
      return acc;
    },
    { total: 0, paid: 0, balance: 0, count: 0 }
  );

  res.json({
    studentId: String(studentId),
    year: year ? Number(year) : null,
    term: term ? String(term) : null,
    ...summary,
    latestInvoice: invoices[0] || null,
  });
});

/**
 * --------------------
 * Payments
 * --------------------
 */

router.post("/payments", requireRole("ADMIN"), requireEntitlement("FEES_WRITE"), async (req, res) => {
  try {
    const { invoiceId, amount, method = "CASH", reference, clientTxnId } = req.body;

    if (!invoiceId || amount === undefined || amount === null) {
      return res.status(400).json({ message: "invoiceId and amount are required." });
    }

    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) {
      return res.status(400).json({ message: "amount must be > 0." });
    }

    const normalizedMethod = normalizePaymentMethod(method);
    if (!normalizedMethod) {
      return res.status(400).json({
        message: `Invalid payment method. Allowed: ${ALLOWED_PAYMENT_METHODS.join(", ")}`,
      });
    }

    const result = await prisma.$transaction(async (tx) => {
      // ✅ Idempotency: if clientTxnId already processed, return existing payment
      const txnId = clientTxnId ? String(clientTxnId) : null;
      if (txnId) {
        const existing = await tx.feePayment.findFirst({
          where: { schoolId: req.schoolId, clientTxnId: txnId },
          include: { invoice: true },
        });
        if (existing) {
          return { payment: existing, invoice: existing.invoice, idempotent: true };
        }
      }

      const invoice = await tx.feeInvoice.findFirst({
        where: { id: String(invoiceId), schoolId: req.schoolId },
      });
      if (!invoice) {
        const e = new Error("Invoice not found.");
        e.status = 404;
        throw e;
      }

      if (amt > invoice.balance) {
        const e = new Error(`Overpayment not allowed. Balance is ${invoice.balance}.`);
        e.status = 400;
        throw e;
      }

      const receiptNo = makeReceiptNo();

      const payment = await tx.feePayment.create({
        data: {
          schoolId: req.schoolId,
          invoiceId: invoice.id,
          clientTxnId: txnId,
          amount: amt,
          method: normalizedMethod,
          reference: reference ? String(reference) : null,
          receivedBy: req.user?.sub || req.user?.id || null,
          receiptNo,
          receiptIssuedAt: new Date(),
        },
      });

      const newPaid = Number(invoice.paid) + amt;
      const { balance: newBalance, status: newStatus } = computeInvoiceStatus(invoice.total, newPaid);

      const updatedInvoice = await tx.feeInvoice.update({
        where: { id: invoice.id },
        data: { paid: newPaid, balance: newBalance, status: newStatus },
      });

      return { payment, invoice: updatedInvoice, idempotent: false };
    });

    return res.status(201).json(result);
  } catch (err) {
    console.error("PAYMENT ERROR:", err);

    const status = err?.status || 500;
    if (err?.code === "P2003") return res.status(400).json({ message: "Bad foreign key (invoiceId?)" });
    if (err?.code === "P2002") return res.status(409).json({ message: "Duplicate payment key. Retry." });

    return res.status(status).json({ message: err?.message || "Server error" });
  }
});

router.post("/payments/:id/reverse", requireRole("ADMIN"), requireEntitlement("FEES_WRITE"), async (req, res) => {
  try {
    const { id } = req.params;
    const reason = String(req.body?.reason || "").trim();

    if (!reason) return res.status(400).json({ message: "Reversal reason is required." });

    const result = await prisma.$transaction(async (tx) => {
      const payment = await tx.feePayment.findFirst({
        where: { id: String(id), schoolId: req.schoolId },
      });
      if (!payment) {
        const e = new Error("Payment not found.");
        e.status = 404;
        throw e;
      }

      if (payment.isReversed) {
        const e = new Error("Payment already reversed.");
        e.status = 400;
        throw e;
      }

      const invoice = await tx.feeInvoice.findFirst({
        where: { id: payment.invoiceId, schoolId: req.schoolId },
      });
      if (!invoice) {
        const e = new Error("Invoice not found for payment.");
        e.status = 404;
        throw e;
      }

      const newPaid = Math.max(Number(invoice.paid) - Number(payment.amount), 0);
      const { balance: newBalance, status: newStatus } = computeInvoiceStatus(invoice.total, newPaid);

      const reversedPayment = await tx.feePayment.update({
        where: { id: payment.id },
        data: {
          isReversed: true,
          reversedAt: new Date(),
          reversedBy: req.user?.sub || req.user?.id || null,
          reversalReason: reason,
        },
      });

      const updatedInvoice = await tx.feeInvoice.update({
        where: { id: invoice.id },
        data: { paid: newPaid, balance: newBalance, status: newStatus },
      });

      return { payment: reversedPayment, invoice: updatedInvoice };
    });

    return res.json({ message: "Payment reversed successfully.", ...result });
  } catch (err) {
    console.error("REVERSE PAYMENT ERROR:", err);
    return res.status(err?.status || 500).json({ message: err?.message || "Server error" });
  }
});

// GET /api/fees/payments/:id/receipt
router.get("/payments/:id/receipt", async (req, res) => {
  try {
    const { id } = req.params;

    const payment = await prisma.feePayment.findFirst({
      where: { id: String(id), schoolId: req.schoolId },
      include: { invoice: true },
    });

    if (!payment) return res.status(404).json({ message: "Payment not found." });

    // ✅ multitenant-safe student lookup
    const student = await prisma.student.findFirst({
      where: { id: payment.invoice.studentId, schoolId: req.schoolId },
      select: { id: true, admissionNo: true, firstName: true, lastName: true, classId: true },
    });

    return res.json({
      receiptNo: payment.receiptNo,
      receiptIssuedAt: payment.receiptIssuedAt,
      isReversed: payment.isReversed,
      reversedAt: payment.reversedAt,
      reversalReason: payment.reversalReason,
      payment: {
        id: payment.id,
        amount: payment.amount,
        method: payment.method,
        reference: payment.reference,
        receivedAt: payment.receivedAt,
        receivedBy: payment.receivedBy,
      },
      invoice: {
        id: payment.invoice.id,
        year: payment.invoice.year,
        term: payment.invoice.term,
        total: payment.invoice.total,
        paid: payment.invoice.paid,
        balance: payment.invoice.balance,
        status: payment.invoice.status,
      },
      student,
      schoolId: req.schoolId,
    });
  } catch (err) {
    console.error("RECEIPT ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// GET /api/fees/students/:studentId/statement?year=2026&term=TERM1
router.get("/students/:studentId/statement", async (req, res) => {
  try {
    const { studentId } = req.params;
    const { year, term } = req.query;

    if (req.user?.role === "STUDENT") {
      const me = await prisma.student.findFirst({
        where: { userId: req.user.sub || req.user.id, schoolId: req.schoolId },
        select: { id: true },
      });

      if (!me || me.id !== String(studentId)) {
        return res.status(403).json({ message: "Students can only view their own statement." });
      }
    }

    const student = await prisma.student.findFirst({
      where: { id: String(studentId), schoolId: req.schoolId },
      select: { id: true, admissionNo: true, firstName: true, lastName: true, classId: true },
    });

    if (!student) return res.status(404).json({ message: "Student not found." });

    const invoices = await prisma.feeInvoice.findMany({
      where: {
        schoolId: req.schoolId,
        studentId: String(studentId),
        year: year ? Number(year) : undefined,
        term: term ? String(term) : undefined,
        status: { not: "VOID" },
      },
      include: { lines: true, payments: true },
      orderBy: { createdAt: "asc" },
    });

    const timeline = [];
    for (const inv of invoices) {
      timeline.push({
        type: "INVOICE",
        at: inv.createdAt,
        ref: inv.id,
        year: inv.year,
        term: inv.term,
        amount: inv.total,
        status: inv.status,
      });

      for (const p of inv.payments.filter((x) => !x.isReversed)) {
        timeline.push({
          type: "PAYMENT",
          at: p.receivedAt,
          ref: p.id,
          receiptNo: p.receiptNo,
          method: p.method,
          reference: p.reference,
          amount: p.amount,
        });
      }
    }

    timeline.sort((a, b) => new Date(a.at) - new Date(b.at));

    const totals = invoices.reduce(
      (acc, inv) => {
        acc.totalBilled += inv.total;
        acc.totalPaid += inv.paid;
        acc.totalBalance += inv.balance;
        acc.invoiceCount += 1;
        return acc;
      },
      { totalBilled: 0, totalPaid: 0, totalBalance: 0, invoiceCount: 0 }
    );

    return res.json({
      student,
      filters: { year: year ? Number(year) : null, term: term ? String(term) : null },
      totals,
      invoices,
      timeline,
    });
  } catch (err) {
    console.error("STATEMENT ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// GET /api/fees/payments/:id/receipt.pdf
router.get("/payments/:id/receipt.pdf", async (req, res) => {
  try {
    const { id } = req.params;

    const payment = await prisma.feePayment.findFirst({
      where: { id: String(id), schoolId: req.schoolId },
      include: { invoice: true },
    });

    if (!payment) return res.status(404).json({ message: "Payment not found." });

    const student = await prisma.student.findFirst({
      where: { id: payment.invoice.studentId, schoolId: req.schoolId },
      select: { admissionNo: true, firstName: true, lastName: true },
    });

    const doc = new PDFDocument({ margin: 50 });
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename=receipt-${payment.receiptNo}.pdf`);
    doc.pipe(res);

    // ✅ Watermark if reversed
    if (payment.isReversed) {
      doc.save();
      doc.rotate(-25, { origin: [100, 300] });
      doc.fontSize(60).fillColor("gray").opacity(0.25).text("REVERSED", 80, 250);
      doc.opacity(1).fillColor("black");
      doc.restore();
      doc.moveDown();
    }

    doc.fontSize(18).text("SCHOOL FEES RECEIPT", { align: "center" });
    doc.moveDown();

    const issuedAt = payment.receiptIssuedAt
      ? new Date(payment.receiptIssuedAt)
      : payment.receivedAt
      ? new Date(payment.receivedAt)
      : new Date();

    doc.fontSize(11);
    doc.text(`Receipt No: ${payment.receiptNo || "—"}`);
    doc.text(`Date: ${issuedAt.toDateString()}`);
    doc.text(`Status: ${payment.isReversed ? "REVERSED" : "POSTED"}`);
    if (payment.isReversed) {
      doc.text(`Reversed At: ${payment.reversedAt ? new Date(payment.reversedAt).toLocaleString() : "—"}`);
      doc.text(`Reason: ${payment.reversalReason || "—"}`);
    }
    doc.moveDown();

    doc.text(`Student: ${student?.firstName || "—"} ${student?.lastName || ""}`);
    doc.text(`Admission No: ${student?.admissionNo || "—"}`);
    doc.moveDown();

    doc.text(`Amount Paid: ${payment.amount}`);
    doc.text(`Payment Method: ${payment.method}`);
    if (payment.reference) doc.text(`Reference: ${payment.reference}`);
    doc.text(`Received By: ${payment.receivedBy || "—"}`);
    doc.moveDown();

    doc.text(`Invoice Total: ${payment.invoice.total}`);
    doc.text(`Total Paid: ${payment.invoice.paid}`);
    doc.text(`Balance: ${payment.invoice.balance}`);
    doc.moveDown();

    doc.text("Thank you.", { align: "center" });
    doc.end();
  } catch (err) {
    console.error("RECEIPT PDF ERROR:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// Reports (unchanged logic, but keep formatting clean)
router.get("/reports/class-summary", requireRole("ADMIN"), async (req, res) => {
  try {
    const { classId, year, term } = req.query;

    if (!classId || !year || !term) {
      return res.status(400).json({ message: "classId, year, and term are required." });
    }

    const invoices = await prisma.feeInvoice.findMany({
      where: {
        schoolId: req.schoolId,
        classId: String(classId),
        year: Number(year),
        term: String(term),
        status: { not: "VOID" },
      },
      select: { total: true, paid: true, balance: true, status: true },
    });

    const summary = invoices.reduce(
      (acc, inv) => {
        acc.totalBilled += inv.total;
        acc.totalPaid += inv.paid;
        acc.totalBalance += inv.balance;
        acc.invoiceCount += 1;
        acc.statusCounts[inv.status] = (acc.statusCounts[inv.status] || 0) + 1;
        return acc;
      },
      { totalBilled: 0, totalPaid: 0, totalBalance: 0, invoiceCount: 0, statusCounts: {} }
    );

    return res.json({ classId: String(classId), year: Number(year), term: String(term), ...summary });
  } catch (err) {
    console.error("CLASS SUMMARY REPORT ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

router.get("/reports/defaulters", requireRole("ADMIN"), async (req, res) => {
  try {
    const { classId, year, term, minBalance = 1, limit = 50 } = req.query;

    if (!classId || !year || !term) {
      return res.status(400).json({ message: "classId, year, and term are required." });
    }

    const invoices = await prisma.feeInvoice.findMany({
      where: {
        schoolId: req.schoolId,
        classId: String(classId),
        year: Number(year),
        term: String(term),
        balance: { gt: Number(minBalance) },
        status: { not: "VOID" },
      },
      orderBy: { balance: "desc" },
      take: Number(limit),
      select: {
        id: true,
        studentId: true,
        total: true,
        paid: true,
        balance: true,
        status: true,
        createdAt: true,
      },
    });

    const studentIds = [...new Set(invoices.map((i) => i.studentId))];

    // ✅ multitenant-safe student lookup
    const students = await prisma.student.findMany({
      where: { id: { in: studentIds }, schoolId: req.schoolId },
      select: { id: true, admissionNo: true, firstName: true, lastName: true },
    });

    const studentMap = new Map(students.map((s) => [s.id, s]));

    const rows = invoices.map((inv) => ({
      invoiceId: inv.id,
      student: studentMap.get(inv.studentId) || { id: inv.studentId },
      total: inv.total,
      paid: inv.paid,
      balance: inv.balance,
      status: inv.status,
      createdAt: inv.createdAt,
    }));

    return res.json({
      classId: String(classId),
      year: Number(year),
      term: String(term),
      minBalance: Number(minBalance),
      count: rows.length,
      rows,
    });
  } catch (err) {
    console.error("DEFAULTERS REPORT ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

router.get("/reports/collections", requireRole("ADMIN"), async (req, res) => {
  try {
    const { from, to } = req.query;

    if (!from || !to) {
      return res.status(400).json({ message: "from and to are required (YYYY-MM-DD)." });
    }

    const fromDate = new Date(`${from}T00:00:00.000Z`);
    const toDate = new Date(`${to}T23:59:59.999Z`);

    const payments = await prisma.feePayment.findMany({
      where: {
        schoolId: req.schoolId,
        receivedAt: { gte: fromDate, lte: toDate },
        isReversed: false,
      },
      select: { amount: true, method: true, receivedAt: true, receiptNo: true, reference: true, invoiceId: true },
      orderBy: { receivedAt: "desc" },
    });

    const totals = payments.reduce(
      (acc, p) => {
        acc.totalCollected += p.amount;
        acc.byMethod[p.method] = (acc.byMethod[p.method] || 0) + p.amount;
        acc.count += 1;
        return acc;
      },
      { totalCollected: 0, count: 0, byMethod: {} }
    );

    return res.json({ from, to, ...totals, payments });
  } catch (err) {
    console.error("COLLECTIONS REPORT ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

export default router;
