// src/routes/settings.js
import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { clearSettingsCache } from "../middleware/features.js";

const router = Router();

const FLAG_KEYS = ["enableClassTeachers", "enableSubjectAssignments"];

// Get settings (ADMIN)
router.get("/", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    let settings = await prisma.schoolSettings.findFirst();
    if (!settings) settings = await prisma.schoolSettings.create({ data: {} });
    return res.json(settings);
  } catch (err) {
    console.error("GET SETTINGS ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// Update settings (ADMIN)
router.patch("/", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    // Reject unknown fields
    for (const key of Object.keys(req.body || {})) {
      if (!FLAG_KEYS.includes(key)) {
        return res.status(400).json({ message: `Unknown field: ${key}` });
      }
    }

    const { enableClassTeachers, enableSubjectAssignments } = req.body || {};

    // Validate types (only if provided)
    if ("enableClassTeachers" in (req.body || {}) && typeof enableClassTeachers !== "boolean") {
      return res.status(400).json({ message: "enableClassTeachers must be boolean" });
    }
    if (
      "enableSubjectAssignments" in (req.body || {}) &&
      typeof enableSubjectAssignments !== "boolean"
    ) {
      return res.status(400).json({ message: "enableSubjectAssignments must be boolean" });
    }

    let settings = await prisma.schoolSettings.findFirst();
    if (!settings) settings = await prisma.schoolSettings.create({ data: {} });

    const updated = await prisma.schoolSettings.update({
      where: { id: settings.id },
      data: {
        ...(typeof enableClassTeachers === "boolean" ? { enableClassTeachers } : {}),
        ...(typeof enableSubjectAssignments === "boolean"
          ? { enableSubjectAssignments }
          : {}),
      },
    });

    // Ensure feature-flag middleware reflects changes immediately
    clearSettingsCache();

    return res.json(updated);
  } catch (err) {
    console.error("UPDATE SETTINGS ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

export default router;
