import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = Router();

// Helpers
const toDateOrNull = (value) => {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
};

const pickStudentUpdate = (body) => {
  // Only allow these fields to be updated
  const allowed = ["admissionNo", "firstName", "lastName", "gender", "dob", "classId", "isActive"];

  const data = {};
  for (const k of allowed) data[k] = body?.[k];

  // Normalize
  if ("admissionNo" in data && data.admissionNo != null) {
    data.admissionNo = String(data.admissionNo).trim();
  }
  if ("firstName" in data && data.firstName != null) {
    data.firstName = String(data.firstName).trim();
  }
  if ("lastName" in data && data.lastName != null) {
    data.lastName = String(data.lastName).trim();
  }
  if ("gender" in data && data.gender != null) {
    data.gender = String(data.gender).trim();
  }
  if ("classId" in data && data.classId != null) {
    data.classId = String(data.classId);
  }
  if ("dob" in data) data.dob = toDateOrNull(data.dob);

  // Prevent setting undefined
  Object.keys(data).forEach((k) => data[k] === undefined && delete data[k]);

  return data;
};

/**
 * STUDENTS
 * Base path: /api/students
 */

// ADMIN: Create student
router.post("/", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    const { admissionNo, firstName, lastName, gender, dob, classId } = req.body || {};

    if (!admissionNo || !firstName || !lastName) {
      return res.status(400).json({ message: "admissionNo, firstName, lastName are required" });
    }

    const created = await prisma.student.create({
      data: {
        admissionNo: String(admissionNo).trim(),
        firstName: String(firstName).trim(),
        lastName: String(lastName).trim(),
        gender: gender ? String(gender).trim() : null,
        dob: dob ? toDateOrNull(dob) : null,
        classId: classId ? String(classId) : null,
        isActive: true,
      },
      include: { class: true },
    });

    return res.status(201).json(created);
  } catch (err) {
    if (err?.code === "P2002") {
      return res.status(409).json({ message: "Admission number already exists" });
    }
    console.error("CREATE STUDENT ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// ADMIN + TEACHER: Lookup student by admissionNo (fast cashier flow)
// GET /api/students/lookup?admissionNo=6333
router.get("/lookup", requireAuth, requireRole("ADMIN", "TEACHER"), async (req, res) => {
  try {
    const admissionNo = String(req.query.admissionNo || "").trim();

    if (!admissionNo) {
      return res.status(400).json({ message: "admissionNo is required" });
    }

    const student = await prisma.student.findFirst({
      where: {
        admissionNo,
        isActive: true,
      },
      include: { class: true },
    });

    if (!student) return res.status(404).json({ message: "Student not found" });

    // 🔒 TEACHER scope enforcement: teacher can only view students in assigned class(es)
    if (req.user?.role === "TEACHER") {
      const teacherId = req.user.teacherId;
      if (!teacherId) return res.status(403).json({ message: "Forbidden" });

      const isAssigned = await prisma.classTeacher.findFirst({
        where: {
          teacherId: String(teacherId),
          classId: student.classId ?? "__none__",
          isActive: true,
        },
        select: { id: true },
      });

      if (!isAssigned) return res.status(403).json({ message: "Forbidden: not your assigned class" });
    }

    return res.json({ student });
  } catch (err) {
    console.error("LOOKUP STUDENT ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});


// ADMIN + TEACHER: List students
// Optional query params:
// - active=true/false (default true)
// - classId=...
router.get("/", requireAuth, requireRole("ADMIN", "TEACHER"), async (req, res) => {
  try {
    const activeParam = req.query.active;
    const active =
      activeParam === undefined ? true : String(activeParam).toLowerCase() === "true";

    const where = {
      isActive: active,
      ...(req.query.classId ? { classId: String(req.query.classId) } : {}),
    };

    // 🔒 TEACHER scope enforcement: teacher can only view students in assigned class(es)
    if (req.user?.role === "TEACHER") {
      const teacherId = req.user.teacherId;

      // If the TEACHER user isn't linked to a Teacher record, return empty list (safe default)
      if (!teacherId) return res.json([]);

      const assigned = await prisma.classTeacher.findMany({
        where: { teacherId: String(teacherId), isActive: true },
        select: { classId: true },
      });

      const allowedClassIds = assigned.map((x) => x.classId);

      // No assigned class => empty list
      if (allowedClassIds.length === 0) return res.json([]);

      // If classId filter is provided, it must be one of the teacher's assigned classes
      if (where.classId && !allowedClassIds.includes(where.classId)) {
        return res.status(403).json({ message: "Forbidden: not your assigned class" });
      }

      // If no classId filter provided, restrict to assigned classes
      if (!where.classId) where.classId = { in: allowedClassIds };
    }

    const students = await prisma.student.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: { class: true },
    });

    return res.json(students);
  } catch (err) {
    console.error("LIST STUDENTS ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// ADMIN + TEACHER: Get one student
router.get("/:id", requireAuth, requireRole("ADMIN", "TEACHER"), async (req, res) => {
  try {
    const student = await prisma.student.findUnique({
      where: { id: req.params.id },
      include: { class: true },
    });

    if (!student) return res.status(404).json({ message: "Student not found" });

    // Optional extra hardening (recommended):
    // If TEACHER, ensure this student is in one of teacher's assigned classes
    if (req.user?.role === "TEACHER") {
      const teacherId = req.user.teacherId;
      if (!teacherId) return res.status(403).json({ message: "Forbidden" });

      const isAssigned = await prisma.classTeacher.findFirst({
        where: { teacherId: String(teacherId), classId: student.classId ?? "__none__", isActive: true },
        select: { id: true },
      });

      if (!isAssigned) return res.status(403).json({ message: "Forbidden" });
    }

    return res.json(student);
  } catch (err) {
    console.error("GET STUDENT ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// ADMIN: Update student
router.patch("/:id", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    const data = pickStudentUpdate(req.body);

    const updated = await prisma.student.update({
      where: { id: req.params.id },
      data,
      include: { class: true },
    });

    return res.json(updated);
  } catch (err) {
    if (err?.code === "P2025") {
      return res.status(404).json({ message: "Student not found" });
    }
    if (err?.code === "P2002") {
      return res.status(409).json({ message: "Admission number already exists" });
    }
    console.error("UPDATE STUDENT ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// ADMIN: Assign / change class
router.patch("/:id/assign-class", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    const { classId } = req.body || {};
    if (!classId) return res.status(400).json({ message: "classId is required" });

    const updated = await prisma.student.update({
      where: { id: req.params.id },
      data: { classId: String(classId) },
      include: { class: true },
    });

    return res.json(updated);
  } catch (err) {
    if (err?.code === "P2025") {
      return res.status(404).json({ message: "Student not found" });
    }
    console.error("ASSIGN CLASS ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// ADMIN: Deactivate student (soft delete)
router.patch("/:id/deactivate", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    const updated = await prisma.student.update({
      where: { id: req.params.id },
      data: { isActive: false },
      include: { class: true },
    });

    return res.json({ message: "Student deactivated", student: updated });
  } catch (err) {
    if (err?.code === "P2025") {
      return res.status(404).json({ message: "Student not found" });
    }
    console.error("DEACTIVATE STUDENT ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

export default router;
