import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { requireFeature } from "../middleware/features.js";

const router = Router();
const cleanStr = (v) => (typeof v === "string" ? v.trim() : "");

router.post(
  "/",
  requireAuth,
  requireRole("ADMIN"),
  requireFeature("enableSubjectAssignments"),
  async (req, res) => {
    try {
      const name = cleanStr(req.body?.name);
      const codeRaw = req.body?.code;
      const code = codeRaw ? cleanStr(codeRaw) : null;

      if (!name) return res.status(400).json({ message: "name is required" });

      const created = await prisma.subject.create({
        data: { name, code: code || null },
      });

      return res.status(201).json(created);
    } catch (err) {
      if (err?.code === "P2002") {
        return res.status(409).json({ message: "Subject name/code already exists" });
      }
      console.error("CREATE SUBJECT ERROR:", err);
      return res.status(500).json({ message: "Server error" });
    }
  }
);

router.get(
  "/",
  requireAuth,
  requireRole("ADMIN", "TEACHER"),
  requireFeature("enableSubjectAssignments"),
  async (req, res) => {
    try {
      const subjects = await prisma.subject.findMany({
        where: { isActive: true },
        orderBy: { name: "asc" },
      });
      return res.json(subjects);
    } catch (err) {
      console.error("LIST SUBJECTS ERROR:", err);
      return res.status(500).json({ message: "Server error" });
    }
  }
);

export default router;
