import { Router } from "express";
import bcrypt from "bcrypt";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = Router();

const cleanStr = (v) => (typeof v === "string" ? v.trim() : "");
const cleanEmail = (email) => String(email || "").trim().toLowerCase();

/**
 * TEACHERS
 * Base path: /api/teachers
 */

// ADMIN: Create teacher (creates a User + Teacher profile in one transaction)
router.post("/", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    const email = cleanEmail(req.body?.email);
    const password = String(req.body?.password || "");
    const firstName = cleanStr(req.body?.firstName);
    const lastName = cleanStr(req.body?.lastName);
    const phone = req.body?.phone ? cleanStr(req.body.phone) : null;

    if (!email || !password || !firstName || !lastName) {
      return res.status(400).json({
        message: "email, password, firstName, lastName are required",
      });
    }

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) return res.status(409).json({ message: "Email already exists" });

    const hashed = await bcrypt.hash(password, 10);

    const result = await prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: {
          email,
          password: hashed,
          role: "TEACHER",
          isActive: true,
        },
        select: { id: true, email: true, role: true, isActive: true, createdAt: true },
      });

      const teacher = await tx.teacher.create({
        data: {
          userId: user.id,
          firstName,
          lastName,
          phone,
        },
        include: { user: { select: { id: true, email: true, role: true, isActive: true } } },
      });

      return teacher;
    });

    return res.status(201).json(result);
  } catch (err) {
    if (err?.code === "P2002") {
      return res.status(409).json({ message: "Duplicate value (email/userId/unique field)" });
    }
    console.error("CREATE TEACHER ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// ADMIN + TEACHER: List teachers
router.get("/", requireAuth, requireRole("ADMIN", "TEACHER"), async (req, res) => {
  try {
    const teachers = await prisma.teacher.findMany({
      orderBy: { createdAt: "desc" },
      include: { user: { select: { id: true, email: true, role: true, isActive: true } } },
    });
    return res.json(teachers);
  } catch (err) {
    console.error("LIST TEACHERS ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// ADMIN + TEACHER: Get one teacher
router.get("/:id", requireAuth, requireRole("ADMIN", "TEACHER"), async (req, res) => {
  try {
    const teacher = await prisma.teacher.findUnique({
      where: { id: req.params.id },
      include: { user: { select: { id: true, email: true, role: true, isActive: true } } },
    });
    if (!teacher) return res.status(404).json({ message: "Teacher not found" });
    return res.json(teacher);
  } catch (err) {
    console.error("GET TEACHER ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// ADMIN: Update teacher profile
router.patch("/:id", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    const data = {};
    if ("firstName" in req.body) data.firstName = cleanStr(req.body.firstName);
    if ("lastName" in req.body) data.lastName = cleanStr(req.body.lastName);
    if ("phone" in req.body) data.phone = req.body.phone ? cleanStr(req.body.phone) : null;

    const updated = await prisma.teacher.update({
      where: { id: req.params.id },
      data,
      include: { user: { select: { id: true, email: true, role: true, isActive: true } } },
    });

    return res.json(updated);
  } catch (err) {
    if (err?.code === "P2025") return res.status(404).json({ message: "Teacher not found" });
    console.error("UPDATE TEACHER ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// ADMIN: Deactivate teacher (soft disable the user account)
router.patch("/:id/deactivate", requireAuth, requireRole("ADMIN"), async (req, res) => {
  try {
    const teacher = await prisma.teacher.findUnique({ where: { id: req.params.id } });
    if (!teacher) return res.status(404).json({ message: "Teacher not found" });

    const updatedUser = await prisma.user.update({
      where: { id: teacher.userId },
      data: { isActive: false },
      select: { id: true, email: true, role: true, isActive: true },
    });

    return res.json({ message: "Teacher deactivated", user: updatedUser });
  } catch (err) {
    console.error("DEACTIVATE TEACHER ERROR:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

export default router;
